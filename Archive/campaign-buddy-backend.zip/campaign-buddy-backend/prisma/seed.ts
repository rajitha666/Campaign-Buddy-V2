import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  // --- Roles (matches Admin Panel spec §3.15, plus new supervisor/sponsor) ---
  await prisma.role.createMany({
    data: [
      { id: "adm", label: "Super Admin", description: "Administrator of the system", modules: ["*"], functionality: ["*"], defaultUrl: "/dashboard" },
      { id: "usr", label: "Campaign Admin", description: "Campaign admin user", modules: ["campaigns", "staff", "sales"], functionality: ["view", "add", "edit"], defaultUrl: "/dashboard" },
      { id: "supervisor", label: "Supervisor", description: "Read-only attendance/sales/tracking for assigned outlets", modules: ["attendance", "sales", "tracking"], functionality: ["view"], defaultUrl: "/portal/campaigns" },
      { id: "sponsor", label: "Sponsor", description: "Read-only live campaign stats for the sponsoring client", modules: ["stats", "reports", "tracking"], functionality: ["view"], defaultUrl: "/portal/campaigns" },
    ],
    skipDuplicates: true,
  });

  // --- Super Admin login ---
  const adminPasswordHash = await bcrypt.hash("ChangeMe123!", 10);
  const admin = await prisma.user.upsert({
    where: { username: "admin" },
    create: { username: "admin", passwordHash: adminPasswordHash, displayName: "Dyuro Super Admin", roleId: "adm" },
    update: {},
  });

  // --- Sample catalog ---
  const client = await prisma.client.upsert({
    where: { id: "00000000-0000-0000-0000-000000000001" },
    create: {
      id: "00000000-0000-0000-0000-000000000001",
      companyName: "Prisha Naturals (Pvt) Ltd",
      clientName: "Ishara Fernando",
      contactNumber: "+94112345678",
      email: "ishara@prishanaturals.lk",
    },
    update: {},
  });

  const brand = await prisma.brand.upsert({
    where: { id: "00000000-0000-0000-0000-000000000002" },
    create: { id: "00000000-0000-0000-0000-000000000002", name: "Prisha Naturals", clientId: client.id },
    update: {},
  });

  const item = await prisma.item.upsert({
    where: { id: "00000000-0000-0000-0000-000000000003" },
    create: {
      id: "00000000-0000-0000-0000-000000000003",
      brandId: brand.id,
      sku: "TF-320-TT",
      name: "Sulfate Free Shampoo — Tea Tree Essential Oil 320ml",
      unitPrice: 3200,
      reorderLevel: 5,
      description: "A gentle, sulfate-free formula infused with tea tree essential oil.",
      attributes: ["320ml", "Sulfate-free", "Paraben-free", "Cruelty-free", "Tea tree scent"],
      supplierName: "Prisha Naturals",
    },
    update: {},
  });

  const city = await prisma.city.upsert({
    where: { id: "00000000-0000-0000-0000-000000000004" },
    create: { id: "00000000-0000-0000-0000-000000000004", name: "Nawala", province: "Western", district: "Colombo" },
    update: {},
  });

  const outlet = await prisma.outlet.upsert({
    where: { id: "00000000-0000-0000-0000-000000000005" },
    create: {
      id: "00000000-0000-0000-0000-000000000005",
      outletNo: "out0001",
      name: "Nawala Retail Outlet",
      cityId: city.id,
      latitude: 6.8845,
      longitude: 79.8887,
      geofenceRadiusMeters: 150,
    },
    update: {},
  });

  const campaign = await prisma.campaign.upsert({
    where: { id: "00000000-0000-0000-0000-000000000006" },
    create: {
      id: "00000000-0000-0000-0000-000000000006",
      campaignNo: "CMP-0001",
      name: "Sktest Activation",
      clientId: client.id,
      startDate: new Date("2026-09-01"),
      endDate: new Date("2026-09-14"),
      status: "active",
    },
    update: {},
  });

  await prisma.campaignAccessGrant.upsert({
    where: { userId_campaignId: { userId: admin.id, campaignId: campaign.id } },
    create: { userId: admin.id, campaignId: campaign.id, scopeType: "all", outletIds: [] },
    update: {},
  });

  const campaignItem = await prisma.campaignItem.upsert({
    where: { campaignId_itemId: { campaignId: campaign.id, itemId: item.id } },
    create: { campaignId: campaign.id, itemId: item.id },
    update: {},
  });

  const staffPasswordHash = await bcrypt.hash("Field123!", 10);
  const staff = await prisma.staff.upsert({
    where: { mobileUsername: "sktest" },
    create: {
      employeeId: "DYR-0142",
      fullName: "Sanduni Kumari",
      displayName: "Sanduni Kumari",
      userType: "promoter",
      mobileUsername: "sktest",
      passwordHash: staffPasswordHash,
      phone: "+94771234567",
      cityId: city.id,
      status: "active",
    },
    update: {},
  });

  const activation = await prisma.activation.upsert({
    where: { id: "00000000-0000-0000-0000-000000000007" },
    create: {
      id: "00000000-0000-0000-0000-000000000007",
      name: "Sktest Activation — Nawala",
      campaignId: campaign.id,
      outletId: outlet.id,
      staffId: staff.id,
      dateFrom: new Date("2026-09-01"),
      dateTo: new Date("2026-09-14"),
      shiftStart: new Date("2026-09-05T03:30:00Z"),
      shiftEnd: new Date("2026-09-05T12:30:00Z"),
    },
    update: {},
  });

  await prisma.activationItem.upsert({
    where: { activationId_campaignItemId: { activationId: activation.id, campaignItemId: campaignItem.id } },
    create: { activationId: activation.id, campaignItemId: campaignItem.id },
    update: {},
  });

  console.log("Seed complete.");
  console.log("Admin login: admin / ChangeMe123!");
  console.log("Mobile login: sktest / Field123!");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
