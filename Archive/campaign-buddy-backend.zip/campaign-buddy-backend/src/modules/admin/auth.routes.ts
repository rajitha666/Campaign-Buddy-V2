import { Router } from "express";
import { prisma } from "../../config/prisma";
import { ApiError, ok } from "../../utils/apiResponse";
import { asyncHandler } from "../../middleware/errorHandler";
import { verifyPassword } from "../../utils/password";
import { signUserAccessToken } from "../../utils/jwt";

const router = Router();

// POST /admin/v1/auth/login — single login for Admin, Supervisor, and Sponsor personas
router.post(
  "/login",
  asyncHandler(async (req, res) => {
    const { username, password } = req.body as { username?: string; password?: string };
    if (!username || !password) {
      throw new ApiError(400, "VALIDATION_ERROR", "username and password are required");
    }

    const user = await prisma.user.findUnique({ where: { username }, include: { role: true } });
    if (!user || !user.isActive || !(await verifyPassword(password, user.passwordHash))) {
      throw new ApiError(401, "VALIDATION_ERROR", "Invalid credentials");
    }

    const accessToken = signUserAccessToken({ sub: user.id, roleId: user.roleId });

    return ok(res, {
      accessToken,
      user: {
        id: user.id,
        displayName: user.displayName,
        roleId: user.roleId,
        defaultUrl: user.role.defaultUrl,
      },
    });
  })
);

export default router;
