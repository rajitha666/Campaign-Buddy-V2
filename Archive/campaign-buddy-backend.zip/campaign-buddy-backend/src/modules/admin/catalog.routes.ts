import { Router } from "express";
import { prisma } from "../../config/prisma";
import { ApiError, ok, okList } from "../../utils/apiResponse";
import { asyncHandler } from "../../middleware/errorHandler";
import { userAuth, requireRole } from "../../middleware/userAuth";

const router = Router();
router.use(userAuth);

// ---------------------------------------------------------------- Clients
router.get(
  "/clients",
  asyncHandler(async (req, res) => {
    const clients = await prisma.client.findMany({ orderBy: { companyName: "asc" } });
    return okList(res, clients, clients.length);
  })
);

router.post(
  "/clients",
  requireRole("adm", "usr"),
  asyncHandler(async (req, res) => {
    const { companyName, clientName, contactNumber, email, address } = req.body;
    if (!companyName || !clientName) {
      throw new ApiError(400, "VALIDATION_ERROR", "companyName and clientName are required");
    }
    const client = await prisma.client.create({
      data: { companyName, clientName, contactNumber, email, address },
    });
    return ok(res, client, 201);
  })
);

router.patch(
  "/clients/:id",
  requireRole("adm", "usr"),
  asyncHandler(async (req, res) => {
    const client = await prisma.client.update({ where: { id: req.params.id }, data: req.body });
    return ok(res, client);
  })
);

router.delete(
  "/clients/:id",
  requireRole("adm"),
  asyncHandler(async (req, res) => {
    await prisma.client.delete({ where: { id: req.params.id } });
    return ok(res, { deleted: true });
  })
);

// ---------------------------------------------------------------- Brands
router.get(
  "/brands",
  asyncHandler(async (req, res) => {
    const clientId = req.query.clientId as string | undefined;
    const brands = await prisma.brand.findMany({
      where: clientId ? { clientId } : undefined,
      orderBy: { name: "asc" },
    });
    return okList(res, brands, brands.length);
  })
);

router.post(
  "/brands",
  requireRole("adm", "usr"),
  asyncHandler(async (req, res) => {
    const { name, clientId } = req.body;
    if (!name || !clientId) throw new ApiError(400, "VALIDATION_ERROR", "name and clientId are required");
    const brand = await prisma.brand.create({ data: { name, clientId } });
    return ok(res, brand, 201);
  })
);

// ---------------------------------------------------------------- Items
router.get(
  "/items",
  asyncHandler(async (req, res) => {
    const search = req.query.search as string | undefined;
    const items = await prisma.item.findMany({
      where: search
        ? { OR: [{ name: { contains: search, mode: "insensitive" } }, { sku: { contains: search, mode: "insensitive" } }] }
        : undefined,
      include: { brand: true },
      orderBy: { name: "asc" },
      take: 50,
    });
    return okList(res, items, items.length);
  })
);

router.post(
  "/items",
  requireRole("adm", "usr"),
  asyncHandler(async (req, res) => {
    const { brandId, sku, name, unitPrice, reorderLevel, imageUrl, description, attributes, supplierName } = req.body;
    if (!brandId || !sku || !name || unitPrice == null) {
      throw new ApiError(400, "VALIDATION_ERROR", "brandId, sku, name, unitPrice are required");
    }
    const item = await prisma.item.create({
      data: { brandId, sku, name, unitPrice, reorderLevel: reorderLevel ?? 0, imageUrl, description, attributes: attributes ?? [], supplierName },
    });
    return ok(res, item, 201);
  })
);

router.patch(
  "/items/:id",
  requireRole("adm", "usr"),
  asyncHandler(async (req, res) => {
    const item = await prisma.item.update({ where: { id: req.params.id }, data: req.body });
    return ok(res, item);
  })
);

// ---------------------------------------------------------------- Cities
router.get(
  "/cities",
  asyncHandler(async (req, res) => {
    const cities = await prisma.city.findMany({ orderBy: { name: "asc" } });
    return okList(res, cities, cities.length);
  })
);

router.post(
  "/cities",
  requireRole("adm"),
  asyncHandler(async (req, res) => {
    const { name, province, district } = req.body;
    if (!name || !province || !district) {
      throw new ApiError(400, "VALIDATION_ERROR", "name, province, district are required");
    }
    const city = await prisma.city.create({ data: { name, province, district } });
    return ok(res, city, 201);
  })
);

// ---------------------------------------------------------------- Outlets
router.get(
  "/outlets",
  asyncHandler(async (req, res) => {
    const search = req.query.search as string | undefined;
    const outlets = await prisma.outlet.findMany({
      where: search ? { name: { contains: search, mode: "insensitive" } } : undefined,
      include: { city: true },
      orderBy: { name: "asc" },
    });
    return okList(res, outlets, outlets.length);
  })
);

router.post(
  "/outlets",
  requireRole("adm", "usr"),
  asyncHandler(async (req, res) => {
    const { outletNo, name, contactPerson, address, cityId, phone, mobile, fax, latitude, longitude, geofenceRadiusMeters } =
      req.body;
    if (!outletNo || !name || !cityId || latitude == null || longitude == null) {
      throw new ApiError(400, "VALIDATION_ERROR", "outletNo, name, cityId, latitude, longitude are required");
    }
    const outlet = await prisma.outlet.create({
      data: {
        outletNo,
        name,
        contactPerson,
        address,
        cityId,
        phone,
        mobile,
        fax,
        latitude,
        longitude,
        geofenceRadiusMeters: geofenceRadiusMeters ?? 150,
      },
    });
    return ok(res, outlet, 201);
  })
);

router.patch(
  "/outlets/:id",
  requireRole("adm", "usr"),
  asyncHandler(async (req, res) => {
    const outlet = await prisma.outlet.update({ where: { id: req.params.id }, data: req.body });
    return ok(res, outlet);
  })
);

// ---------------------------------------------------------------- Distributor Points
router.get(
  "/distributor-points",
  asyncHandler(async (req, res) => {
    const points = await prisma.distributorPoint.findMany({ include: { city: true } });
    return okList(res, points, points.length);
  })
);

router.post(
  "/distributor-points",
  requireRole("adm", "usr"),
  asyncHandler(async (req, res) => {
    const { name, contact, address, cityId, clientId } = req.body;
    if (!name || !cityId || !clientId) {
      throw new ApiError(400, "VALIDATION_ERROR", "name, cityId, clientId are required");
    }
    const point = await prisma.distributorPoint.create({ data: { name, contact, address, cityId, clientId } });
    return ok(res, point, 201);
  })
);

export default router;
