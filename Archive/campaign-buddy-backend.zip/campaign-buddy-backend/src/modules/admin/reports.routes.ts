import { Router } from "express";
import { prisma } from "../../config/prisma";
import { ok } from "../../utils/apiResponse";
import { asyncHandler } from "../../middleware/errorHandler";
import { outletIdsAllowed } from "../../middleware/campaignAccess";

// Mounted with mergeParams under /admin/v1/campaigns/:campaignId/reports, behind requireCampaignAccess.
const router = Router({ mergeParams: true });

async function scopedActivationIds(req: any) {
  const allowedOutlets = outletIdsAllowed(req);
  const activations = await prisma.activation.findMany({
    where: {
      campaignId: req.params.campaignId,
      ...(allowedOutlets ? { outletId: { in: allowedOutlets } } : {}),
    },
    select: { id: true },
  });
  return activations.map((a) => a.id);
}

// GET /admin/v1/campaigns/:campaignId/reports/sku-wise
router.get(
  "/sku-wise",
  asyncHandler(async (req, res) => {
    const activationIds = await scopedActivationIds(req);
    const records = await prisma.salesRecord.findMany({
      where: { activationItem: { activationId: { in: activationIds } } },
      include: { activationItem: { include: { campaignItem: { include: { item: { include: { brand: true } } } } } } },
    });

    const byItem = new Map<string, { itemId: string; name: string; brand: string; itemCount: number; totalSales: number }>();
    for (const r of records) {
      const item = r.activationItem.campaignItem.item;
      const existing = byItem.get(item.id) ?? { itemId: item.id, name: item.name, brand: item.brand.name, itemCount: 0, totalSales: 0 };
      existing.itemCount += r.soldToday;
      existing.totalSales += r.soldToday * item.unitPrice;
      byItem.set(item.id, existing);
    }

    const rows = Array.from(byItem.values()).sort((a, b) => b.totalSales - a.totalSales);
    const grandTotal = rows.reduce((s, r) => s + r.totalSales, 0);
    return ok(res, { rows, grandTotal });
  })
);

// GET /admin/v1/campaigns/:campaignId/reports/brand-wise
router.get(
  "/brand-wise",
  asyncHandler(async (req, res) => {
    const activationIds = await scopedActivationIds(req);
    const records = await prisma.salesRecord.findMany({
      where: { activationItem: { activationId: { in: activationIds } } },
      include: { activationItem: { include: { campaignItem: { include: { item: { include: { brand: true } } } } } } },
    });

    const byBrand = new Map<string, { brandId: string; brand: string; itemCount: number; totalSales: number }>();
    for (const r of records) {
      const brand = r.activationItem.campaignItem.item.brand;
      const existing = byBrand.get(brand.id) ?? { brandId: brand.id, brand: brand.name, itemCount: 0, totalSales: 0 };
      existing.itemCount += r.soldToday;
      existing.totalSales += r.soldToday * r.activationItem.campaignItem.item.unitPrice;
      byBrand.set(brand.id, existing);
    }

    const rows = Array.from(byBrand.values()).sort((a, b) => b.totalSales - a.totalSales);
    const grandTotal = rows.reduce((s, r) => s + r.totalSales, 0);
    return ok(res, { rows, grandTotal });
  })
);

// GET /admin/v1/campaigns/:campaignId/reports/reorder — items at/below reorderLevel
router.get(
  "/reorder",
  asyncHandler(async (req, res) => {
    const activationIds = await scopedActivationIds(req);
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const records = await prisma.salesRecord.findMany({
      where: { activationItem: { activationId: { in: activationIds } }, date: today, reorderFlag: true },
      include: {
        activationItem: {
          include: {
            activation: { include: { outlet: true } },
            campaignItem: { include: { item: true } },
          },
        },
      },
    });

    const rows = records.map((r) => ({
      activation: r.activationItem.activation.id,
      item: r.activationItem.campaignItem.item.name,
      outlet: r.activationItem.activation.outlet.name,
      date: r.date,
      remainingStock: r.openingStock - r.soldToday,
    }));

    return ok(res, rows);
  })
);

// GET /admin/v1/campaigns/:campaignId/reports/attendance-monthly?month=09-2026
router.get(
  "/attendance-monthly",
  asyncHandler(async (req, res) => {
    const month = req.query.month as string; // "MM-YYYY"
    const [mm, yyyy] = month.split("-").map(Number);
    const from = new Date(yyyy, mm - 1, 1);
    const to = new Date(yyyy, mm, 0);

    const activationIds = await scopedActivationIds(req);
    const records = await prisma.attendanceRecord.findMany({
      where: { activationId: { in: activationIds }, date: { gte: from, lte: to } },
      include: { activation: { include: { staff: true, outlet: true } } },
    });

    const byActivation = new Map<string, any>();
    for (const r of records) {
      const key = r.activationId;
      if (!byActivation.has(key)) {
        byActivation.set(key, {
          promoter: r.activation.staff.fullName,
          outlet: r.activation.outlet.name,
          activation: r.activation.name,
          days: {} as Record<number, string>,
        });
      }
      byActivation.get(key).days[r.date.getDate()] = r.status;
    }

    return ok(res, Array.from(byActivation.values()));
  })
);

export default router;
