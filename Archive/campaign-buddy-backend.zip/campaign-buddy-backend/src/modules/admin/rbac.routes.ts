import { Router } from "express";
import { prisma } from "../../config/prisma";
import { ApiError, ok, okList } from "../../utils/apiResponse";
import { asyncHandler } from "../../middleware/errorHandler";
import { userAuth, requireRole } from "../../middleware/userAuth";
import { hashPassword } from "../../utils/password";

const router = Router();
router.use(userAuth, requireRole("adm"));

// ---------------------------------------------------------------- Users
router.get(
  "/users",
  asyncHandler(async (req, res) => {
    const users = await prisma.user.findMany({
      include: { role: true },
      orderBy: { createdAt: "desc" },
    });
    return okList(
      res,
      users.map(({ passwordHash, ...u }) => u),
      users.length
    );
  })
);

router.post(
  "/users",
  asyncHandler(async (req, res) => {
    const { username, password, displayName, email, roleId } = req.body;
    if (!username || !password || !displayName || !roleId) {
      throw new ApiError(400, "VALIDATION_ERROR", "username, password, displayName, roleId are required");
    }

    const passwordHash = await hashPassword(password);
    const user = await prisma.user.create({
      data: { username, passwordHash, displayName, email, roleId },
    });
    return ok(res, { ...user, passwordHash: undefined }, 201);
  })
);

router.patch(
  "/users/:id",
  asyncHandler(async (req, res) => {
    const { password, ...rest } = req.body;
    const data: Record<string, unknown> = { ...rest };
    if (password) data.passwordHash = await hashPassword(password);
    const user = await prisma.user.update({ where: { id: req.params.id }, data });
    return ok(res, { ...user, passwordHash: undefined });
  })
);

// ---------------------------------------------------------------- CampaignAccessGrant
// GET /admin/v1/users/:id/campaign-access
router.get(
  "/users/:id/campaign-access",
  asyncHandler(async (req, res) => {
    const grants = await prisma.campaignAccessGrant.findMany({
      where: { userId: req.params.id },
      include: { campaign: true },
    });
    return okList(res, grants, grants.length);
  })
);

// POST /admin/v1/users/:id/campaign-access — grant/update access to a campaign
// body: { campaignId, scopeType: "all" | "subset", outletIds?: string[] }
router.post(
  "/users/:id/campaign-access",
  asyncHandler(async (req, res) => {
    const { campaignId, scopeType, outletIds } = req.body as {
      campaignId?: string;
      scopeType?: "all" | "subset";
      outletIds?: string[];
    };
    if (!campaignId || !scopeType) {
      throw new ApiError(400, "VALIDATION_ERROR", "campaignId and scopeType are required");
    }
    if (scopeType === "subset" && (!outletIds || outletIds.length === 0)) {
      throw new ApiError(400, "VALIDATION_ERROR", "outletIds is required when scopeType is 'subset'", "outletIds");
    }

    const grant = await prisma.campaignAccessGrant.upsert({
      where: { userId_campaignId: { userId: req.params.id, campaignId } },
      create: { userId: req.params.id, campaignId, scopeType, outletIds: outletIds ?? [] },
      update: { scopeType, outletIds: outletIds ?? [] },
    });

    return ok(res, grant, 201);
  })
);

router.delete(
  "/users/:id/campaign-access/:campaignId",
  asyncHandler(async (req, res) => {
    await prisma.campaignAccessGrant.delete({
      where: { userId_campaignId: { userId: req.params.id, campaignId: req.params.campaignId } },
    });
    return ok(res, { deleted: true });
  })
);

// ---------------------------------------------------------------- Roles
router.get(
  "/roles",
  asyncHandler(async (req, res) => {
    const roles = await prisma.role.findMany();
    return okList(res, roles, roles.length);
  })
);

router.post(
  "/roles",
  asyncHandler(async (req, res) => {
    const { id, label, description, modules, functionality, defaultUrl } = req.body;
    if (!id || !label || !defaultUrl) {
      throw new ApiError(400, "VALIDATION_ERROR", "id, label, defaultUrl are required");
    }
    const role = await prisma.role.create({
      data: { id, label, description, modules: modules ?? [], functionality: functionality ?? [], defaultUrl },
    });
    return ok(res, role, 201);
  })
);

export default router;
