import { Router } from "express";
import { prisma } from "../../config/prisma";
import { ApiError, ok, okList } from "../../utils/apiResponse";
import { asyncHandler } from "../../middleware/errorHandler";
import { userAuth, requireRole } from "../../middleware/userAuth";
import { hashPassword } from "../../utils/password";

const router = Router();
router.use(userAuth);

// GET /admin/v1/staff?search=&userType= — global pool, for assigning to an Activation
router.get(
  "/",
  asyncHandler(async (req, res) => {
    const search = req.query.search as string | undefined;
    const userType = req.query.userType as "promoter" | "supervisor" | undefined;

    const staff = await prisma.staff.findMany({
      where: {
        ...(userType ? { userType } : {}),
        ...(search
          ? {
              OR: [
                { fullName: { contains: search, mode: "insensitive" } },
                { employeeId: { contains: search, mode: "insensitive" } },
                { mobileUsername: { contains: search, mode: "insensitive" } },
              ],
            }
          : {}),
      },
      orderBy: { fullName: "asc" },
      take: 50,
      select: {
        id: true,
        employeeId: true,
        fullName: true,
        displayName: true,
        userType: true,
        mobileUsername: true,
        phone: true,
        status: true,
        cityId: true,
      },
    });

    return okList(res, staff, staff.length);
  })
);

// POST /admin/v1/staff — create a new Staff member (new hire) inline while assigning
router.post(
  "/",
  requireRole("adm", "usr"),
  asyncHandler(async (req, res) => {
    const {
      employeeId,
      fullName,
      displayName,
      userType,
      mobileUsername,
      password,
      phone,
      cityId,
      reportsToStaffId,
    } = req.body as Record<string, string>;

    if (!employeeId || !fullName || !userType || !mobileUsername || !password) {
      throw new ApiError(
        400,
        "VALIDATION_ERROR",
        "employeeId, fullName, userType, mobileUsername, password are required"
      );
    }

    const passwordHash = await hashPassword(password);
    const staff = await prisma.staff.create({
      data: {
        employeeId,
        fullName,
        displayName: displayName ?? fullName,
        userType: userType as any,
        mobileUsername,
        passwordHash,
        phone,
        cityId,
        reportsToStaffId,
      },
    });

    return ok(res, { ...staff, passwordHash: undefined }, 201);
  })
);

router.patch(
  "/:id",
  requireRole("adm", "usr"),
  asyncHandler(async (req, res) => {
    const { password, ...rest } = req.body as Record<string, string>;
    const data: Record<string, unknown> = { ...rest };
    if (password) data.passwordHash = await hashPassword(password);

    const staff = await prisma.staff.update({ where: { id: req.params.id }, data });
    return ok(res, { ...staff, passwordHash: undefined });
  })
);

export default router;
