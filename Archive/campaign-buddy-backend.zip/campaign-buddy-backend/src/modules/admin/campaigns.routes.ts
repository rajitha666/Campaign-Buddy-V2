import { Router } from "express";
import { prisma } from "../../config/prisma";
import { ApiError, ok, okList } from "../../utils/apiResponse";
import { asyncHandler } from "../../middleware/errorHandler";
import { userAuth, requireRole } from "../../middleware/userAuth";
import { requireCampaignAccess } from "../../middleware/campaignAccess";

const router = Router();
router.use(userAuth);

// GET /admin/v1/campaigns — list scoped to caller's CampaignAccessGrants (Super Admin sees all)
router.get(
  "/",
  asyncHandler(async (req, res) => {
    let campaigns;
    if (req.user!.roleId === "adm") {
      campaigns = await prisma.campaign.findMany({ include: { client: true }, orderBy: { startDate: "desc" } });
    } else {
      const grants = await prisma.campaignAccessGrant.findMany({
        where: { userId: req.user!.sub },
        include: { campaign: { include: { client: true } } },
      });
      campaigns = grants.map((g) => g.campaign);
    }

    return okList(res, campaigns, campaigns.length);
  })
);

// POST /admin/v1/campaigns — create (Admin only); creator gets an implicit "all outlets" grant
router.post(
  "/",
  requireRole("adm", "usr"),
  asyncHandler(async (req, res) => {
    const { campaignNo, name, clientId, description, startDate, endDate, timezone } = req.body;
    if (!campaignNo || !name || !clientId || !startDate || !endDate) {
      throw new ApiError(400, "VALIDATION_ERROR", "campaignNo, name, clientId, startDate, endDate are required");
    }

    const campaign = await prisma.campaign.create({
      data: {
        campaignNo,
        name,
        clientId,
        description,
        startDate: new Date(startDate),
        endDate: new Date(endDate),
        timezone: timezone ?? "Asia/Colombo",
      },
    });

    await prisma.campaignAccessGrant.create({
      data: { userId: req.user!.sub, campaignId: campaign.id, scopeType: "all", outletIds: [] },
    });

    return ok(res, campaign, 201);
  })
);

// Everything below is scoped to one campaign the caller has a grant for.
const scoped = Router({ mergeParams: true });
scoped.use(requireCampaignAccess);
router.use("/:campaignId", scoped);

scoped.get(
  "/",
  asyncHandler(async (req, res) => {
    const campaign = await prisma.campaign.findUnique({
      where: { id: req.params.campaignId },
      include: { client: true },
    });
    if (!campaign) throw new ApiError(404, "NOT_FOUND", "Campaign not found");
    return ok(res, campaign);
  })
);

scoped.patch(
  "/",
  requireRole("adm", "usr"),
  asyncHandler(async (req, res) => {
    const { startDate, endDate, ...rest } = req.body;
    const campaign = await prisma.campaign.update({
      where: { id: req.params.campaignId },
      data: {
        ...rest,
        ...(startDate ? { startDate: new Date(startDate) } : {}),
        ...(endDate ? { endDate: new Date(endDate) } : {}),
      },
    });
    return ok(res, campaign);
  })
);

// GET /admin/v1/campaigns/:campaignId/access — everyone with portal access to this campaign
// (a campaign can have any number of Sponsor/Supervisor/Admin Users, each with their own grant)
scoped.get(
  "/access",
  requireRole("adm", "usr"),
  asyncHandler(async (req, res) => {
    const grants = await prisma.campaignAccessGrant.findMany({
      where: { campaignId: req.params.campaignId },
      include: { user: { include: { role: true } } },
    });
    return okList(
      res,
      grants.map((g) => ({
        userId: g.userId,
        displayName: g.user.displayName,
        roleId: g.user.roleId,
        roleLabel: g.user.role.label,
        scopeType: g.scopeType,
        outletIds: g.outletIds,
      })),
      grants.length
    );
  })
);

// GET /admin/v1/campaigns/:campaignId/items — this campaign's CampaignItem list
scoped.get(
  "/items",
  asyncHandler(async (req, res) => {
    const campaignItems = await prisma.campaignItem.findMany({
      where: { campaignId: req.params.campaignId },
      include: { item: { include: { brand: true } } },
    });
    return okList(res, campaignItems, campaignItems.length);
  })
);

// POST /admin/v1/campaigns/:campaignId/items — link an existing Item, or create + link a new one
scoped.post(
  "/items",
  requireRole("adm", "usr"),
  asyncHandler(async (req, res) => {
    const { itemId, newItem } = req.body as {
      itemId?: string;
      newItem?: {
        brandId: string;
        sku: string;
        name: string;
        unitPrice: number;
        reorderLevel?: number;
        imageUrl?: string;
        description?: string;
        attributes?: string[];
        supplierName?: string;
      };
    };

    let resolvedItemId = itemId;
    if (!resolvedItemId) {
      if (!newItem) throw new ApiError(400, "VALIDATION_ERROR", "Provide itemId or newItem");
      const created = await prisma.item.create({
        data: { ...newItem, reorderLevel: newItem.reorderLevel ?? 0, attributes: newItem.attributes ?? [] },
      });
      resolvedItemId = created.id;
    }

    const campaignItem = await prisma.campaignItem.upsert({
      where: { campaignId_itemId: { campaignId: req.params.campaignId, itemId: resolvedItemId } },
      create: { campaignId: req.params.campaignId, itemId: resolvedItemId },
      update: {},
      include: { item: true },
    });

    return ok(res, campaignItem, 201);
  })
);

scoped.delete(
  "/items/:campaignItemId",
  requireRole("adm", "usr"),
  asyncHandler(async (req, res) => {
    await prisma.campaignItem.delete({ where: { id: req.params.campaignItemId } });
    return ok(res, { deleted: true });
  })
);

export default router;
export { scoped as campaignScopedRouter };
