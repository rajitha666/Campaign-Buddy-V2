import { Router } from "express";
import { prisma } from "../../config/prisma";
import { ApiError, ok, okList } from "../../utils/apiResponse";
import { asyncHandler } from "../../middleware/errorHandler";
import { requireRole } from "../../middleware/userAuth";
import { assertOutletAllowed, outletIdsAllowed } from "../../middleware/campaignAccess";

// Mounted with mergeParams under /admin/v1/campaigns/:campaignId, behind requireCampaignAccess.
const router = Router({ mergeParams: true });

function dateRangeFromQuery(req: any) {
  const from = req.query.dateFrom ? new Date(req.query.dateFrom as string) : undefined;
  const to = req.query.dateTo ? new Date(req.query.dateTo as string) : undefined;
  return { from, to };
}

async function scopedActivationIds(req: any, extraOutletId?: string) {
  const allowedOutlets = outletIdsAllowed(req);
  const outletFilter = extraOutletId
    ? { outletId: extraOutletId }
    : allowedOutlets
    ? { outletId: { in: allowedOutlets } }
    : {};
  if (extraOutletId) assertOutletAllowed(req, extraOutletId);

  const activations = await prisma.activation.findMany({
    where: { campaignId: req.params.campaignId, ...outletFilter },
    select: { id: true },
  });
  return activations.map((a) => a.id);
}

// GET /admin/v1/campaigns/:campaignId/attendance?outletId=&dateFrom=&dateTo=
router.get(
  "/attendance",
  asyncHandler(async (req, res) => {
    const outletId = req.query.outletId as string | undefined;
    const { from, to } = dateRangeFromQuery(req);
    const activationIds = await scopedActivationIds(req, outletId);

    const records = await prisma.attendanceRecord.findMany({
      where: {
        activationId: { in: activationIds },
        ...(from || to ? { date: { ...(from ? { gte: from } : {}), ...(to ? { lte: to } : {}) } } : {}),
      },
      include: { activation: { include: { staff: true, outlet: true } } },
      orderBy: { date: "desc" },
    });

    return okList(res, records, records.length);
  })
);

// GET /admin/v1/campaigns/:campaignId/sales?outletId=&dateFrom=&dateTo=
router.get(
  "/sales",
  asyncHandler(async (req, res) => {
    const outletId = req.query.outletId as string | undefined;
    const { from, to } = dateRangeFromQuery(req);
    const activationIds = await scopedActivationIds(req, outletId);

    const records = await prisma.salesRecord.findMany({
      where: {
        activationItem: { activationId: { in: activationIds } },
        ...(from || to ? { date: { ...(from ? { gte: from } : {}), ...(to ? { lte: to } : {}) } } : {}),
      },
      include: {
        activationItem: {
          include: {
            activation: { include: { staff: true, outlet: true } },
            campaignItem: { include: { item: { include: { brand: true } } } },
          },
        },
      },
      orderBy: { date: "desc" },
    });

    return okList(res, records, records.length);
  })
);

// PATCH /admin/v1/campaigns/:campaignId/sales/:salesRecordId — Admin-only correction
router.patch(
  "/sales/:salesRecordId",
  requireRole("adm", "usr"),
  asyncHandler(async (req, res) => {
    const record = await prisma.salesRecord.findUnique({
      where: { id: req.params.salesRecordId },
      include: { activationItem: { include: { activation: true } } },
    });
    if (!record || record.activationItem.activation.campaignId !== req.params.campaignId) {
      throw new ApiError(404, "NOT_FOUND", "Sales record not found");
    }
    assertOutletAllowed(req, record.activationItem.activation.outletId);

    const { openingStock, soldToday, otherInterestedCustomers, reorderFlag } = req.body;
    const updated = await prisma.salesRecord.update({
      where: { id: req.params.salesRecordId },
      data: { openingStock, soldToday, otherInterestedCustomers, reorderFlag },
    });
    return ok(res, updated);
  })
);

// GET /admin/v1/campaigns/:campaignId/stats?outletId=&dateFrom=&dateTo= — DailyStats rollup
router.get(
  "/stats",
  asyncHandler(async (req, res) => {
    const outletId = req.query.outletId as string | undefined;
    const { from, to } = dateRangeFromQuery(req);
    const activationIds = await scopedActivationIds(req, outletId);

    const stats = await prisma.dailyStats.findMany({
      where: {
        activationId: { in: activationIds },
        ...(from || to ? { date: { ...(from ? { gte: from } : {}), ...(to ? { lte: to } : {}) } } : {}),
      },
    });

    const totals = stats.reduce(
      (acc, s) => ({
        footFall: acc.footFall + s.footFall,
        approached: acc.approached + s.approached,
        converted: acc.converted + s.converted,
      }),
      { footFall: 0, approached: 0, converted: 0 }
    );

    return ok(res, { totals, byDay: stats });
  })
);

// GET /admin/v1/campaigns/:campaignId/tracking/live — current position of every checked-in staff member
router.get(
  "/tracking/live",
  asyncHandler(async (req, res) => {
    const activationIds = await scopedActivationIds(req);

    const openRecords = await prisma.attendanceRecord.findMany({
      where: { activationId: { in: activationIds }, checkInAt: { not: null }, checkOutAt: null },
      include: { activation: { include: { staff: true, outlet: true } } },
    });

    const live = await Promise.all(
      openRecords.map(async (record) => {
        const lastPing = await prisma.trackingPing.findFirst({
          where: { activationId: record.activationId },
          orderBy: { capturedAt: "desc" },
        });
        return {
          staffId: record.activation.staff.id,
          staffName: record.activation.staff.fullName,
          outletId: record.activation.outlet.id,
          outletName: record.activation.outlet.name,
          checkInAt: record.checkInAt,
          lastLocation: lastPing
            ? { latitude: lastPing.latitude, longitude: lastPing.longitude, capturedAt: lastPing.capturedAt }
            : null,
        };
      })
    );

    return okList(res, live, live.length);
  })
);

// GET /admin/v1/campaigns/:campaignId/leave-requests
router.get(
  "/leave-requests",
  asyncHandler(async (req, res) => {
    const activationIds = await scopedActivationIds(req);
    const staffIds = (
      await prisma.activation.findMany({ where: { id: { in: activationIds } }, select: { staffId: true } })
    ).map((a) => a.staffId);

    const requests = await prisma.leaveRequest.findMany({
      where: { staffId: { in: staffIds } },
      include: { staff: true },
      orderBy: { createdAt: "desc" },
    });
    return okList(res, requests, requests.length);
  })
);

// PATCH /admin/v1/campaigns/:campaignId/leave-requests/:id — approve/decline
router.patch(
  "/leave-requests/:id",
  requireRole("adm", "usr"),
  asyncHandler(async (req, res) => {
    const { status } = req.body as { status?: "approved" | "declined" };
    if (!status || !["approved", "declined"].includes(status)) {
      throw new ApiError(400, "VALIDATION_ERROR", "status must be 'approved' or 'declined'");
    }
    const updated = await prisma.leaveRequest.update({
      where: { id: req.params.id },
      data: { status, decidedAt: new Date() },
    });
    return ok(res, updated);
  })
);

export default router;
