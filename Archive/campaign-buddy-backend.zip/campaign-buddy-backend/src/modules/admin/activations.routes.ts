import { Router } from "express";
import { prisma } from "../../config/prisma";
import { ApiError, ok, okList } from "../../utils/apiResponse";
import { asyncHandler } from "../../middleware/errorHandler";
import { requireRole } from "../../middleware/userAuth";
import { assertOutletAllowed, outletIdsAllowed } from "../../middleware/campaignAccess";

// Mounted with mergeParams under /admin/v1/campaigns/:campaignId/activations,
// behind requireCampaignAccess already applied by the parent scoped router.
const router = Router({ mergeParams: true });

/**
 * Naming a Staff member as Activation.supervisorStaffId auto-grants/expands
 * their web portal access to this campaign+outlet, IF that Staff record is
 * linked to a User login (Staff.linkedUserId). No-op if the supervisor has
 * no portal login yet — an admin can always link one later via /staff/:id.
 *
 * Existing "all"-outlet grants are left untouched. A "subset" grant gets the
 * new outletId appended if it's missing. If no grant exists yet, one is
 * created scoped to just this outlet. Reassigning a supervisor away from an
 * outlet does NOT revoke prior access — that remains a manual admin action
 * via DELETE /admin/v1/users/:id/campaign-access/:campaignId.
 */
async function ensureSupervisorAccessGrant(supervisorStaffId: string, campaignId: string, outletId: string) {
  const supervisor = await prisma.staff.findUnique({ where: { id: supervisorStaffId } });
  if (!supervisor?.linkedUserId) return;

  const existingGrant = await prisma.campaignAccessGrant.findUnique({
    where: { userId_campaignId: { userId: supervisor.linkedUserId, campaignId } },
  });

  if (!existingGrant) {
    await prisma.campaignAccessGrant.create({
      data: { userId: supervisor.linkedUserId, campaignId, scopeType: "subset", outletIds: [outletId] },
    });
    return;
  }

  if (existingGrant.scopeType === "all") return; // already sees every outlet
  if (!existingGrant.outletIds.includes(outletId)) {
    await prisma.campaignAccessGrant.update({
      where: { id: existingGrant.id },
      data: { outletIds: [...existingGrant.outletIds, outletId] },
    });
  }
}

// GET /admin/v1/campaigns/:campaignId/activations
router.get(
  "/",
  asyncHandler(async (req, res) => {
    const allowedOutlets = outletIdsAllowed(req);
    const activations = await prisma.activation.findMany({
      where: {
        campaignId: req.params.campaignId,
        ...(allowedOutlets ? { outletId: { in: allowedOutlets } } : {}),
      },
      include: { outlet: true, staff: true, supervisor: true },
      orderBy: { dateFrom: "desc" },
    });
    return okList(res, activations, activations.length);
  })
);

// POST /admin/v1/campaigns/:campaignId/activations
router.post(
  "/",
  requireRole("adm", "usr"),
  asyncHandler(async (req, res) => {
    const {
      name,
      outletId,
      staffId,
      supervisorStaffId,
      distributorPointId,
      dateFrom,
      dateTo,
      targetType,
      targetCategorization,
      targetUnit,
      shiftStart,
      shiftEnd,
    } = req.body;

    if (!name || !outletId || !staffId || !dateFrom || !dateTo) {
      throw new ApiError(400, "VALIDATION_ERROR", "name, outletId, staffId, dateFrom, dateTo are required");
    }
    assertOutletAllowed(req, outletId);

    const activation = await prisma.activation.create({
      data: {
        name,
        campaignId: req.params.campaignId,
        outletId,
        staffId,
        supervisorStaffId,
        distributorPointId,
        dateFrom: new Date(dateFrom),
        dateTo: new Date(dateTo),
        targetType: targetType ?? "item_wise",
        targetCategorization: targetCategorization ?? "daily",
        targetUnit: targetUnit ?? "unit_wise",
        shiftStart: shiftStart ? new Date(shiftStart) : undefined,
        shiftEnd: shiftEnd ? new Date(shiftEnd) : undefined,
      },
    });

    if (activation.supervisorStaffId) {
      await ensureSupervisorAccessGrant(activation.supervisorStaffId, req.params.campaignId, activation.outletId);
    }

    return ok(res, activation, 201);
  })
);

async function loadActivationInScope(req: any) {
  const activation = await prisma.activation.findFirst({
    where: { id: req.params.activationId, campaignId: req.params.campaignId },
  });
  if (!activation) throw new ApiError(404, "NOT_FOUND", "Activation not found");
  assertOutletAllowed(req, activation.outletId);
  return activation;
}

router.get(
  "/:activationId",
  asyncHandler(async (req, res) => {
    const activation = await loadActivationInScope(req);
    return ok(res, activation);
  })
);

router.patch(
  "/:activationId",
  requireRole("adm", "usr"),
  asyncHandler(async (req, res) => {
    await loadActivationInScope(req);
    if (req.body.outletId) assertOutletAllowed(req, req.body.outletId);
    const { dateFrom, dateTo, shiftStart, shiftEnd, ...rest } = req.body;
    const updated = await prisma.activation.update({
      where: { id: req.params.activationId },
      data: {
        ...rest,
        ...(dateFrom ? { dateFrom: new Date(dateFrom) } : {}),
        ...(dateTo ? { dateTo: new Date(dateTo) } : {}),
        ...(shiftStart ? { shiftStart: new Date(shiftStart) } : {}),
        ...(shiftEnd ? { shiftEnd: new Date(shiftEnd) } : {}),
      },
    });

    if (updated.supervisorStaffId) {
      await ensureSupervisorAccessGrant(updated.supervisorStaffId, req.params.campaignId, updated.outletId);
    }

    return ok(res, updated);
  })
);

router.delete(
  "/:activationId",
  requireRole("adm", "usr"),
  asyncHandler(async (req, res) => {
    await loadActivationInScope(req);
    await prisma.activation.delete({ where: { id: req.params.activationId } });
    return ok(res, { deleted: true });
  })
);

// POST /.../activations/:activationId/items — attach ActivationItems (single, or "addAll")
router.post(
  "/:activationId/items",
  requireRole("adm", "usr"),
  asyncHandler(async (req, res) => {
    await loadActivationInScope(req);
    const { campaignItemId, addAll } = req.body as { campaignItemId?: string; addAll?: boolean };

    if (addAll) {
      const campaignItems = await prisma.campaignItem.findMany({ where: { campaignId: req.params.campaignId } });
      const created = await prisma.$transaction(
        campaignItems.map((ci) =>
          prisma.activationItem.upsert({
            where: { activationId_campaignItemId: { activationId: req.params.activationId, campaignItemId: ci.id } },
            create: { activationId: req.params.activationId, campaignItemId: ci.id },
            update: {},
          })
        )
      );
      return ok(res, created, 201);
    }

    if (!campaignItemId) throw new ApiError(400, "VALIDATION_ERROR", "campaignItemId or addAll is required");
    const activationItem = await prisma.activationItem.upsert({
      where: { activationId_campaignItemId: { activationId: req.params.activationId, campaignItemId } },
      create: { activationId: req.params.activationId, campaignItemId },
      update: {},
    });
    return ok(res, activationItem, 201);
  })
);

router.delete(
  "/:activationId/items/:activationItemId",
  requireRole("adm", "usr"),
  asyncHandler(async (req, res) => {
    await loadActivationInScope(req);
    await prisma.activationItem.delete({ where: { id: req.params.activationItemId } });
    return ok(res, { deleted: true });
  })
);

// ActivationTarget CRUD
router.get(
  "/:activationId/targets",
  asyncHandler(async (req, res) => {
    await loadActivationInScope(req);
    const targets = await prisma.activationTarget.findMany({ where: { activationId: req.params.activationId } });
    return okList(res, targets, targets.length);
  })
);

router.post(
  "/:activationId/targets",
  requireRole("adm", "usr"),
  asyncHandler(async (req, res) => {
    await loadActivationInScope(req);
    const { dateFrom, dateTo, repeat, targetItemId, targetValue } = req.body;
    if (!dateFrom || !dateTo || !targetItemId || targetValue == null) {
      throw new ApiError(400, "VALIDATION_ERROR", "dateFrom, dateTo, targetItemId, targetValue are required");
    }
    const target = await prisma.activationTarget.create({
      data: {
        activationId: req.params.activationId,
        dateFrom: new Date(dateFrom),
        dateTo: new Date(dateTo),
        repeat: repeat ?? false,
        targetItemId,
        targetValue,
      },
    });
    return ok(res, target, 201);
  })
);

export default router;
