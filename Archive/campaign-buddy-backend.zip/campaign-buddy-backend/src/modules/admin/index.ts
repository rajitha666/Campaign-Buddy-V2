import { Router } from "express";
import authRoutes from "./auth.routes";
import catalogRoutes from "./catalog.routes";
import staffRoutes from "./staff.routes";
import campaignsRoutes, { campaignScopedRouter } from "./campaigns.routes";
import activationsRoutes from "./activations.routes";
import operationsRoutes from "./operations.routes";
import reportsRoutes from "./reports.routes";
import rbacRoutes from "./rbac.routes";

// Nest activations/operations/reports under the already-access-checked
// per-campaign router exported from campaigns.routes.ts, so every one of
// these inherits requireCampaignAccess without re-declaring it.
campaignScopedRouter.use("/activations", activationsRoutes);
campaignScopedRouter.use("/reports", reportsRoutes);
campaignScopedRouter.use("/", operationsRoutes); // attendance, sales, stats, tracking/live, leave-requests

const router = Router();

router.use("/auth", authRoutes);
router.use("/staff", staffRoutes);
router.use("/campaigns", campaignsRoutes);
router.use("/", catalogRoutes); // /clients, /brands, /items, /cities, /outlets, /distributor-points
router.use("/", rbacRoutes); // /users, /users/:id/campaign-access, /roles

export default router;
