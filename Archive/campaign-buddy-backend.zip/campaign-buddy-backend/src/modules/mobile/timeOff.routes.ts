import { Router } from "express";
import { prisma } from "../../config/prisma";
import { ApiError, ok } from "../../utils/apiResponse";
import { asyncHandler } from "../../middleware/errorHandler";
import { staffAuth } from "../../middleware/staffAuth";

const router = Router();
router.use(staffAuth);

// GET /v1/time-off/balance
router.get(
  "/balance",
  asyncHandler(async (req, res) => {
    const staffId = req.staff!.sub;
    const pendingCount = await prisma.leaveRequest.count({ where: { staffId, status: "pending" } });
    const yearStart = new Date(new Date().getFullYear(), 0, 1);
    const takenThisYear = await prisma.leaveRequest.count({
      where: { staffId, status: "approved", fromDate: { gte: yearStart } },
    });
    return ok(res, { pendingCount, takenThisYear });
  })
);

// GET /v1/time-off/requests
router.get(
  "/requests",
  asyncHandler(async (req, res) => {
    const requests = await prisma.leaveRequest.findMany({
      where: { staffId: req.staff!.sub },
      orderBy: { createdAt: "desc" },
    });
    return ok(res, requests);
  })
);

// POST /v1/time-off/requests
router.post(
  "/requests",
  asyncHandler(async (req, res) => {
    const { fromDate, toDate, reason, note } = req.body as {
      fromDate?: string;
      toDate?: string;
      reason?: string;
      note?: string;
    };
    if (!fromDate || !toDate || !reason) {
      throw new ApiError(400, "VALIDATION_ERROR", "fromDate, toDate, reason are required");
    }
    if (new Date(toDate) < new Date(fromDate)) {
      throw new ApiError(400, "VALIDATION_ERROR", "toDate must be on or after fromDate", "toDate");
    }

    const staff = await prisma.staff.findUniqueOrThrow({ where: { id: req.staff!.sub } });

    const overlap = await prisma.leaveRequest.findFirst({
      where: {
        staffId: staff.id,
        status: { in: ["pending", "approved"] },
        fromDate: { lte: new Date(toDate) },
        toDate: { gte: new Date(fromDate) },
      },
    });
    if (overlap) {
      throw new ApiError(409, "OVERLAPPING_LEAVE_REQUEST", "Dates overlap an existing pending/approved request");
    }

    const created = await prisma.leaveRequest.create({
      data: {
        staffId: staff.id,
        fromDate: new Date(fromDate),
        toDate: new Date(toDate),
        reason: reason as any,
        note,
        approverId: staff.reportsToStaffId,
        status: "pending",
      },
    });

    return ok(res, created, 201);
  })
);

export default router;
