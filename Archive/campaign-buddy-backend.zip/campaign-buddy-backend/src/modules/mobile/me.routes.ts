import { Router } from "express";
import { prisma } from "../../config/prisma";
import { ApiError, ok } from "../../utils/apiResponse";
import { asyncHandler } from "../../middleware/errorHandler";
import { staffAuth } from "../../middleware/staffAuth";

const router = Router();
router.use(staffAuth);

// GET /v1/me
router.get(
  "/",
  asyncHandler(async (req, res) => {
    const staff = await prisma.staff.findUniqueOrThrow({
      where: { id: req.staff!.sub },
      include: { reportsTo: true },
    });

    return ok(res, {
      id: staff.id,
      employeeId: staff.employeeId,
      fullName: staff.fullName,
      phone: staff.phone,
      role: staff.userType,
      reportsToName: staff.reportsTo?.fullName ?? null,
    });
  })
);

// GET /v1/me/assignments/today — resolves today's Activation for the logged-in Staff
router.get(
  "/assignments/today",
  asyncHandler(async (req, res) => {
    const startOfDay = new Date();
    startOfDay.setHours(0, 0, 0, 0);
    const endOfDay = new Date();
    endOfDay.setHours(23, 59, 59, 999);

    const activation = await prisma.activation.findFirst({
      where: {
        staffId: req.staff!.sub,
        dateFrom: { lte: endOfDay },
        dateTo: { gte: startOfDay },
      },
      include: { campaign: true, outlet: true },
      orderBy: { dateFrom: "desc" },
    });

    if (!activation) {
      throw new ApiError(404, "NOT_FOUND", "No activation scheduled for today");
    }

    return ok(res, {
      assignmentId: activation.id,
      campaign: {
        id: activation.campaign.id,
        name: activation.campaign.name,
        startDate: activation.campaign.startDate,
      },
      outlet: {
        id: activation.outlet.id,
        name: activation.outlet.name,
        latitude: activation.outlet.latitude,
        longitude: activation.outlet.longitude,
        geofenceRadiusMeters: activation.outlet.geofenceRadiusMeters,
      },
      shiftStart: activation.shiftStart,
      shiftEnd: activation.shiftEnd,
    });
  })
);

export default router;
