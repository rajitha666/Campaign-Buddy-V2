import { Router } from "express";
import { prisma } from "../../config/prisma";
import { ok } from "../../utils/apiResponse";
import { asyncHandler } from "../../middleware/errorHandler";
import { staffAuth } from "../../middleware/staffAuth";

const router = Router();
router.use(staffAuth);

function todayDateOnly(): Date {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  return d;
}

async function getTodayActivationId(staffId: string): Promise<string | null> {
  const startOfDay = todayDateOnly();
  const endOfDay = new Date(startOfDay.getTime() + 24 * 60 * 60 * 1000 - 1);
  const activation = await prisma.activation.findFirst({
    where: { staffId, dateFrom: { lte: endOfDay }, dateTo: { gte: startOfDay } },
  });
  return activation?.id ?? null;
}

async function computeTotalSales(activationId: string, date: Date): Promise<number> {
  const activationItems = await prisma.activationItem.findMany({
    where: { activationId },
    include: { campaignItem: { include: { item: true } }, salesRecords: { where: { date } } },
  });

  return activationItems.reduce((sum, ai) => {
    const record = ai.salesRecords[0];
    if (!record) return sum;
    return sum + record.soldToday * ai.campaignItem.item.unitPrice;
  }, 0);
}

// GET /v1/stats/today
router.get(
  "/today",
  asyncHandler(async (req, res) => {
    const activationId = await getTodayActivationId(req.staff!.sub);
    const date = todayDateOnly();

    if (!activationId) {
      return ok(res, { footFall: 0, approached: 0, converted: 0, conversionRate: 0, totalSales: 0 });
    }

    const stats = await prisma.dailyStats.findUnique({
      where: { activationId_date: { activationId, date } },
    });
    const totalSales = await computeTotalSales(activationId, date);

    const footFall = stats?.footFall ?? 0;
    const approached = stats?.approached ?? 0;
    const converted = stats?.converted ?? 0;

    return ok(res, {
      footFall,
      approached,
      converted,
      conversionRate: approached > 0 ? Number((converted / approached).toFixed(2)) : 0,
      totalSales,
    });
  })
);

// PATCH /v1/stats/today
router.patch(
  "/today",
  asyncHandler(async (req, res) => {
    const activationId = await getTodayActivationId(req.staff!.sub);
    const date = todayDateOnly();
    const { footFall, approached, converted } = req.body as {
      footFall?: number;
      approached?: number;
      converted?: number;
    };

    if (!activationId) {
      return ok(res, { footFall: 0, approached: 0, converted: 0 });
    }

    const updated = await prisma.dailyStats.upsert({
      where: { activationId_date: { activationId, date } },
      create: { activationId, date, footFall: footFall ?? 0, approached: approached ?? 0, converted: converted ?? 0 },
      update: {
        ...(footFall != null ? { footFall } : {}),
        ...(approached != null ? { approached } : {}),
        ...(converted != null ? { converted } : {}),
      },
    });

    return ok(res, updated);
  })
);

export default router;
