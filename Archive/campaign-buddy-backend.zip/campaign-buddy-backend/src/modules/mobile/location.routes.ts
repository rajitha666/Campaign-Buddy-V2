import { Router } from "express";
import { prisma } from "../../config/prisma";
import { ApiError, noContent } from "../../utils/apiResponse";
import { asyncHandler } from "../../middleware/errorHandler";
import { staffAuth } from "../../middleware/staffAuth";

const router = Router();
router.use(staffAuth);

// POST /v1/location/ping
router.post(
  "/ping",
  asyncHandler(async (req, res) => {
    const { latitude, longitude, accuracyMeters, timestamp, batteryPercent } = req.body as {
      latitude?: number;
      longitude?: number;
      accuracyMeters?: number;
      timestamp?: string;
      batteryPercent?: number;
    };
    if (latitude == null || longitude == null || !timestamp) {
      throw new ApiError(400, "VALIDATION_ERROR", "latitude, longitude, timestamp are required");
    }

    // Reject pings with no open (checkInAt set, checkOutAt null) AttendanceRecord for this staff.
    const openRecord = await prisma.attendanceRecord.findFirst({
      where: {
        activation: { staffId: req.staff!.sub },
        checkInAt: { not: null },
        checkOutAt: null,
      },
      orderBy: { checkInAt: "desc" },
    });

    if (!openRecord) {
      throw new ApiError(422, "NOT_CHECKED_IN", "No open shift — pings are only accepted between check-in and check-out");
    }

    await prisma.trackingPing.create({
      data: {
        activationId: openRecord.activationId,
        latitude,
        longitude,
        accuracyMeters,
        capturedAt: new Date(timestamp),
        appState: "foreground",
        batteryPercent,
      },
    });

    return noContent(res);
  })
);

export default router;
