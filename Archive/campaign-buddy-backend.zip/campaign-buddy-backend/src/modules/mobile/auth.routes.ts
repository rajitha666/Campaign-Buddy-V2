import { Router } from "express";
import { v4 as uuidv4 } from "uuid";
import { prisma } from "../../config/prisma";
import { ApiError, noContent, ok } from "../../utils/apiResponse";
import { asyncHandler } from "../../middleware/errorHandler";
import { verifyPassword } from "../../utils/password";
import { signStaffAccessToken } from "../../utils/jwt";
import { env } from "../../config/env";
import { staffAuth } from "../../middleware/staffAuth";
import crypto from "crypto";

const router = Router();

function hashToken(token: string): string {
  return crypto.createHash("sha256").update(token).digest("hex");
}

// POST /v1/auth/login
router.post(
  "/login",
  asyncHandler(async (req, res) => {
    const { username, password } = req.body as { username?: string; password?: string };
    if (!username || !password) {
      throw new ApiError(400, "VALIDATION_ERROR", "username and password are required");
    }

    const staff = await prisma.staff.findUnique({ where: { mobileUsername: username } });
    if (!staff || staff.status !== "active" || !(await verifyPassword(password, staff.passwordHash))) {
      throw new ApiError(401, "VALIDATION_ERROR", "Invalid credentials");
    }

    const accessToken = signStaffAccessToken({ sub: staff.id, userType: staff.userType });

    const refreshToken = uuidv4();
    const expiresAt = new Date(Date.now() + env.staffRefreshTokenTtlDays * 24 * 60 * 60 * 1000);
    await prisma.staffRefreshToken.create({
      data: { staffId: staff.id, tokenHash: hashToken(refreshToken), expiresAt },
    });

    return ok(res, {
      accessToken,
      refreshToken,
      expiresIn: env.staffJwtExpiresIn,
      user: {
        id: staff.id,
        fullName: staff.fullName,
        role: staff.userType,
        employeeId: staff.employeeId,
      },
    });
  })
);

// POST /v1/auth/refresh
router.post(
  "/refresh",
  asyncHandler(async (req, res) => {
    const { refreshToken } = req.body as { refreshToken?: string };
    if (!refreshToken) throw new ApiError(400, "VALIDATION_ERROR", "refreshToken is required");

    const tokenHash = hashToken(refreshToken);
    const stored = await prisma.staffRefreshToken.findFirst({
      where: { tokenHash, revokedAt: null, expiresAt: { gt: new Date() } },
      include: { staff: true },
    });
    if (!stored) throw new ApiError(401, "TOKEN_EXPIRED", "Invalid or expired refresh token");

    const accessToken = signStaffAccessToken({ sub: stored.staff.id, userType: stored.staff.userType });
    return ok(res, { accessToken, expiresIn: env.staffJwtExpiresIn });
  })
);

// POST /v1/auth/forgot-password — always generic to avoid user enumeration
router.post(
  "/forgot-password",
  asyncHandler(async (req, res) => {
    return ok(res, { message: "If the account exists, a reset link was sent" });
  })
);

// POST /v1/auth/logout
router.post(
  "/logout",
  staffAuth,
  asyncHandler(async (req, res) => {
    await prisma.staffRefreshToken.updateMany({
      where: { staffId: req.staff!.sub, revokedAt: null },
      data: { revokedAt: new Date() },
    });
    return noContent(res);
  })
);

export default router;
