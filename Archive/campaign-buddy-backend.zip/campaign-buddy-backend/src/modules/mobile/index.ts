import { Router } from "express";
import authRoutes from "./auth.routes";
import meRoutes from "./me.routes";
import attendanceRoutes from "./attendance.routes";
import locationRoutes from "./location.routes";
import statsRoutes from "./stats.routes";
import productsRoutes from "./products.routes";
import salesSummaryRoutes from "./salesSummary.routes";
import timeOffRoutes from "./timeOff.routes";
import performanceRoutes from "./performance.routes";

const router = Router();

router.use("/auth", authRoutes);
router.use("/me", meRoutes);
router.use("/attendance", attendanceRoutes);
router.use("/location", locationRoutes);
router.use("/stats", statsRoutes);
router.use("/time-off", timeOffRoutes);
router.use("/sales-summary", salesSummaryRoutes);
// These two mount extra path segments themselves (/campaigns/:id/...), so mount at root.
router.use("/", productsRoutes);
router.use("/", performanceRoutes);

export default router;
