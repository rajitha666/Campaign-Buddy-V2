import { Router } from "express";
import { prisma } from "../../config/prisma";
import { ApiError, ok } from "../../utils/apiResponse";
import { asyncHandler } from "../../middleware/errorHandler";
import { staffAuth } from "../../middleware/staffAuth";

const router = Router();
router.use(staffAuth);

// GET /v1/campaigns/:campaignId/performance?outletId=
router.get(
  "/campaigns/:campaignId/performance",
  asyncHandler(async (req, res) => {
    const { campaignId } = req.params;
    const outletId = req.query.outletId as string | undefined;

    const campaign = await prisma.campaign.findUnique({ where: { id: campaignId } });
    if (!campaign) throw new ApiError(404, "NOT_FOUND", "Campaign not found");

    const activation = await prisma.activation.findFirst({
      where: { campaignId, staffId: req.staff!.sub, ...(outletId ? { outletId } : {}) },
    });
    if (!activation) throw new ApiError(404, "NOT_FOUND", "No activation found for this campaign/outlet");

    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const dayNumber =
      Math.floor((today.getTime() - new Date(campaign.startDate).setHours(0, 0, 0, 0)) / (24 * 60 * 60 * 1000)) + 1;
    const totalDays =
      Math.floor(
        (new Date(campaign.endDate).setHours(0, 0, 0, 0) - new Date(campaign.startDate).setHours(0, 0, 0, 0)) /
          (24 * 60 * 60 * 1000)
      ) + 1;

    const activationItems = await prisma.activationItem.findMany({
      where: { activationId: activation.id },
      include: { campaignItem: { include: { item: true } }, salesRecords: true },
    });

    const salesByDate = new Map<string, number>();
    let totalSales = 0;
    let totalUnitsSold = 0;
    const unitsByItem = new Map<string, { name: string; unitPrice: number; unitsSold: number }>();

    for (const ai of activationItems) {
      const item = ai.campaignItem.item;
      for (const record of ai.salesRecords) {
        const amount = record.soldToday * item.unitPrice;
        totalSales += amount;
        totalUnitsSold += record.soldToday;
        const key = record.date.toISOString().slice(0, 10);
        salesByDate.set(key, (salesByDate.get(key) ?? 0) + amount);
      }
      const existing = unitsByItem.get(item.id) ?? { name: item.name, unitPrice: item.unitPrice, unitsSold: 0 };
      existing.unitsSold += ai.salesRecords.reduce((s, r) => s + r.soldToday, 0);
      unitsByItem.set(item.id, existing);
    }

    const totalApproached = await prisma.dailyStats.aggregate({
      where: { activationId: activation.id },
      _sum: { approached: true },
    });

    const dailySales = Array.from(salesByDate.entries())
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([date, amount]) => ({ date, amount }));

    const topProducts = Array.from(unitsByItem.entries())
      .map(([productId, v]) => ({ productId, ...v }))
      .sort((a, b) => b.unitsSold - a.unitsSold);

    return ok(res, {
      campaignName: campaign.name,
      startDate: campaign.startDate,
      dayNumber: Math.max(dayNumber, 1),
      totalDays,
      totalSales,
      totalUnitsSold,
      totalApproached: totalApproached._sum.approached ?? 0,
      dailySales,
      topProducts,
    });
  })
);

export default router;
