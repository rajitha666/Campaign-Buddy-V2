import { Router } from "express";
import { prisma } from "../../config/prisma";
import { ApiError, ok } from "../../utils/apiResponse";
import { asyncHandler } from "../../middleware/errorHandler";
import { staffAuth } from "../../middleware/staffAuth";

const router = Router();
router.use(staffAuth);

function todayDateOnly(): Date {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  return d;
}

async function getTodayActivationOrThrow(staffId: string) {
  const startOfDay = todayDateOnly();
  const endOfDay = new Date(startOfDay.getTime() + 24 * 60 * 60 * 1000 - 1);
  const activation = await prisma.activation.findFirst({
    where: { staffId, dateFrom: { lte: endOfDay }, dateTo: { gte: startOfDay } },
  });
  if (!activation) throw new ApiError(404, "NOT_FOUND", "No activation scheduled for today");
  return activation;
}

async function buildSummary(activationId: string, date: Date) {
  const activationItems = await prisma.activationItem.findMany({
    where: { activationId },
    include: { campaignItem: { include: { item: true } }, salesRecords: { where: { date } } },
  });

  let itemsReceived = 0;
  let itemsSold = 0;
  let itemsRemaining = 0;
  let totalSales = 0;

  for (const ai of activationItems) {
    const record = ai.salesRecords[0];
    const opening = record?.openingStock ?? 0;
    const sold = record?.soldToday ?? 0;
    itemsReceived += opening;
    itemsSold += sold;
    itemsRemaining += opening - sold;
    totalSales += sold * ai.campaignItem.item.unitPrice;
  }

  const stats = await prisma.dailyStats.findUnique({ where: { activationId_date: { activationId, date } } });
  const summary = await prisma.salesSummary.findUnique({ where: { activationId_date: { activationId, date } } });

  return {
    id: summary?.id ?? null,
    itemsReceived,
    itemsSold,
    itemsRemaining,
    totalSales,
    footFall: stats?.footFall ?? 0,
    approached: stats?.approached ?? 0,
    converted: stats?.converted ?? 0,
    remarks: summary?.remarks ?? null,
    confirmed: summary?.confirmed ?? false,
    confirmedAt: summary?.confirmedAt ?? null,
  };
}

// GET /v1/sales-summary/today
router.get(
  "/today",
  asyncHandler(async (req, res) => {
    const activation = await getTodayActivationOrThrow(req.staff!.sub);
    return ok(res, await buildSummary(activation.id, todayDateOnly()));
  })
);

// PATCH /v1/sales-summary/today — remarks only
router.patch(
  "/today",
  asyncHandler(async (req, res) => {
    const activation = await getTodayActivationOrThrow(req.staff!.sub);
    const date = todayDateOnly();
    const { remarks } = req.body as { remarks?: string };

    await prisma.salesSummary.upsert({
      where: { activationId_date: { activationId: activation.id, date } },
      create: { activationId: activation.id, date, remarks },
      update: { remarks },
    });

    return ok(res, await buildSummary(activation.id, date));
  })
);

// POST /v1/sales-summary/today/confirm
router.post(
  "/today/confirm",
  asyncHandler(async (req, res) => {
    const activation = await getTodayActivationOrThrow(req.staff!.sub);
    const date = todayDateOnly();
    const { remarks } = (req.body ?? {}) as { remarks?: string };

    await prisma.salesSummary.upsert({
      where: { activationId_date: { activationId: activation.id, date } },
      create: { activationId: activation.id, date, remarks, confirmed: true, confirmedAt: new Date() },
      update: { ...(remarks != null ? { remarks } : {}), confirmed: true, confirmedAt: new Date() },
    });

    return ok(res, await buildSummary(activation.id, date));
  })
);

export default router;
