import { Router } from "express";
import { prisma } from "../../config/prisma";
import { ApiError, ok } from "../../utils/apiResponse";
import { asyncHandler } from "../../middleware/errorHandler";
import { staffAuth } from "../../middleware/staffAuth";

const router = Router();
router.use(staffAuth);

const GRACE_PERIOD_MINUTES = 10;

function haversineMeters(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 6371000;
  const toRad = (d: number) => (d * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLng = toRad(lng2 - lng1);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function todayDateOnly(): Date {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  return d;
}

async function getOpenActivationOrThrow(staffId: string) {
  const startOfDay = todayDateOnly();
  const endOfDay = new Date(startOfDay.getTime() + 24 * 60 * 60 * 1000 - 1);
  const activation = await prisma.activation.findFirst({
    where: { staffId, dateFrom: { lte: endOfDay }, dateTo: { gte: startOfDay } },
    include: { outlet: true },
  });
  if (!activation) throw new ApiError(404, "NOT_FOUND", "No activation scheduled for today");
  return activation;
}

// GET /v1/attendance/today
router.get(
  "/today",
  asyncHandler(async (req, res) => {
    const activation = await getOpenActivationOrThrow(req.staff!.sub);
    const record = await prisma.attendanceRecord.findUnique({
      where: { activationId_date: { activationId: activation.id, date: todayDateOnly() } },
    });

    if (!record) {
      return ok(res, {
        checkedIn: false,
        checkInAt: null,
        checkOutAt: null,
        shiftDurationSeconds: 0,
        locationVerified: false,
        status: "pending",
      });
    }

    const shiftDurationSeconds = record.checkInAt
      ? Math.floor(((record.checkOutAt ?? new Date()).getTime() - record.checkInAt.getTime()) / 1000)
      : 0;

    return ok(res, {
      checkedIn: Boolean(record.checkInAt && !record.checkOutAt),
      checkInAt: record.checkInAt,
      checkOutAt: record.checkOutAt,
      shiftDurationSeconds,
      locationVerified: record.checkInLocationVerified,
      status: record.status,
    });
  })
);

// POST /v1/attendance/check-in
router.post(
  "/check-in",
  asyncHandler(async (req, res) => {
    const { assignmentId, latitude, longitude, timestamp } = req.body as {
      assignmentId?: string;
      latitude?: number;
      longitude?: number;
      timestamp?: string;
    };
    if (!assignmentId || latitude == null || longitude == null || !timestamp) {
      throw new ApiError(400, "VALIDATION_ERROR", "assignmentId, latitude, longitude, timestamp are required");
    }

    const activation = await prisma.activation.findUnique({
      where: { id: assignmentId },
      include: { outlet: true },
    });
    if (!activation || activation.staffId !== req.staff!.sub) {
      throw new ApiError(404, "NOT_FOUND", "Activation not found");
    }

    const date = todayDateOnly();

    // Global lock: a Staff member may only have one open shift at a time,
    // across ALL campaigns/activations — not just this one. Moonlighting
    // across concurrent campaigns is blocked by policy.
    const openShiftElsewhere = await prisma.attendanceRecord.findFirst({
      where: {
        activation: { staffId: req.staff!.sub },
        checkInAt: { not: null },
        checkOutAt: null,
      },
    });
    if (openShiftElsewhere) {
      throw new ApiError(
        409,
        "ALREADY_CHECKED_IN",
        openShiftElsewhere.activationId === activation.id
          ? "Already checked in today"
          : "You already have an open shift on another campaign — check out there first"
      );
    }

    const distance = haversineMeters(
      latitude,
      longitude,
      activation.outlet.latitude,
      activation.outlet.longitude
    );
    const locationVerified = distance <= activation.outlet.geofenceRadiusMeters;

    let status: "on_time" | "late" = "on_time";
    if (activation.shiftStart) {
      const graceMs = GRACE_PERIOD_MINUTES * 60 * 1000;
      status = new Date(timestamp).getTime() > activation.shiftStart.getTime() + graceMs ? "late" : "on_time";
    }

    const record = await prisma.attendanceRecord.upsert({
      where: { activationId_date: { activationId: activation.id, date } },
      create: {
        activationId: activation.id,
        date,
        checkInAt: new Date(timestamp),
        checkInLat: latitude,
        checkInLng: longitude,
        checkInLocationVerified: locationVerified,
        status,
      },
      update: {
        checkInAt: new Date(timestamp),
        checkInLat: latitude,
        checkInLng: longitude,
        checkInLocationVerified: locationVerified,
        status,
      },
    });

    return ok(res, record, 201);
  })
);

// POST /v1/attendance/check-out
router.post(
  "/check-out",
  asyncHandler(async (req, res) => {
    const { latitude, longitude, timestamp, salesSummaryConfirmed } = req.body as {
      latitude?: number;
      longitude?: number;
      timestamp?: string;
      salesSummaryConfirmed?: boolean;
    };
    if (latitude == null || longitude == null || !timestamp || salesSummaryConfirmed == null) {
      throw new ApiError(400, "VALIDATION_ERROR", "latitude, longitude, timestamp, salesSummaryConfirmed are required");
    }

    const activation = await getOpenActivationOrThrow(req.staff!.sub);
    const date = todayDateOnly();
    const record = await prisma.attendanceRecord.findUnique({
      where: { activationId_date: { activationId: activation.id, date } },
    });

    if (!record?.checkInAt || record.checkOutAt) {
      throw new ApiError(422, "NOT_CHECKED_IN", "No open check-in exists");
    }

    const updated = await prisma.attendanceRecord.update({
      where: { id: record.id },
      data: {
        checkOutAt: new Date(timestamp),
        checkOutLat: latitude,
        checkOutLng: longitude,
        salesSummaryConfirmedAtCheckout: salesSummaryConfirmed,
      },
    });

    return ok(res, updated);
  })
);

// GET /v1/attendance/history?range=week|month
router.get(
  "/history",
  asyncHandler(async (req, res) => {
    const range = (req.query.range as string) ?? "week";
    const days = range === "month" ? 30 : 7;
    const since = new Date();
    since.setDate(since.getDate() - days);

    const activations = await prisma.activation.findMany({ where: { staffId: req.staff!.sub } });
    const activationIds = activations.map((a) => a.id);

    const records = await prisma.attendanceRecord.findMany({
      where: { activationId: { in: activationIds }, date: { gte: since } },
      orderBy: { date: "desc" },
      include: { leaveRequest: true },
    });

    return ok(
      res,
      records.map((r) => ({
        date: r.date,
        checkInAt: r.checkInAt,
        checkOutAt: r.checkOutAt,
        status: r.status,
        leaveReason: r.leaveRequest?.reason ?? null,
      }))
    );
  })
);

export default router;
