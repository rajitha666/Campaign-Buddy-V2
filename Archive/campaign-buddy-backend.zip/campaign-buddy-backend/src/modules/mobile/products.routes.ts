import { Router } from "express";
import { prisma } from "../../config/prisma";
import { ApiError, ok } from "../../utils/apiResponse";
import { asyncHandler } from "../../middleware/errorHandler";
import { staffAuth } from "../../middleware/staffAuth";

const router = Router();
router.use(staffAuth);

function todayDateOnly(): Date {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  return d;
}

// GET /v1/campaigns/:campaignId/outlets/:outletId/products
// Resolves to the logged-in staff's Activation for that campaign+outlet.
router.get(
  "/campaigns/:campaignId/outlets/:outletId/products",
  asyncHandler(async (req, res) => {
    const { campaignId, outletId } = req.params;
    const reorderOnly = req.query.reorderOnly === "true";
    const date = todayDateOnly();

    const activation = await prisma.activation.findFirst({
      where: { campaignId, outletId, staffId: req.staff!.sub },
    });
    if (!activation) throw new ApiError(404, "NOT_FOUND", "No activation found for this campaign/outlet");

    const activationItems = await prisma.activationItem.findMany({
      where: { activationId: activation.id },
      include: {
        campaignItem: { include: { item: true } },
        salesRecords: { where: { date } },
      },
    });

    const rows = activationItems
      .map((ai) => {
        const record = ai.salesRecords[0];
        const openingStock = record?.openingStock ?? 0;
        const soldToday = record?.soldToday ?? 0;
        return {
          campaignProductAssignmentId: ai.id,
          product: {
            id: ai.campaignItem.item.id,
            sku: ai.campaignItem.item.sku,
            name: ai.campaignItem.item.name,
            unitPrice: ai.campaignItem.item.unitPrice,
            imageUrl: ai.campaignItem.item.imageUrl,
          },
          openingStock,
          soldToday,
          remainingStock: openingStock - soldToday,
          reorderFlag: record?.reorderFlag ?? false,
        };
      })
      .filter((row) => !reorderOnly || row.reorderFlag);

    return ok(res, rows);
  })
);

// GET /v1/products/:productId — product details popup
router.get(
  "/products/:productId",
  asyncHandler(async (req, res) => {
    const date = todayDateOnly();
    const item = await prisma.item.findUnique({ where: { id: req.params.productId } });
    if (!item) throw new ApiError(404, "NOT_FOUND", "Product not found");

    const campaignItems = await prisma.campaignItem.findMany({
      where: { itemId: item.id },
      include: { activationItems: { include: { salesRecords: { where: { date } } } } },
    });
    const soldAcrossAllOutletsToday = campaignItems.reduce(
      (sum, ci) => sum + ci.activationItems.reduce((s, ai) => s + (ai.salesRecords[0]?.soldToday ?? 0), 0),
      0
    );
    const earliestAddedAt = campaignItems.reduce<Date | null>((min, ci) => {
      return !min || ci.addedAt < min ? ci.addedAt : min;
    }, null);

    return ok(res, {
      id: item.id,
      sku: item.sku,
      name: item.name,
      unitPrice: item.unitPrice,
      description: item.description,
      attributes: item.attributes,
      supplierName: item.supplierName,
      addedToCampaignAt: earliestAddedAt,
      soldAcrossAllOutletsToday,
    });
  })
);

// PATCH /v1/products/:campaignProductAssignmentId/stock
router.patch(
  "/products/:campaignProductAssignmentId/stock",
  asyncHandler(async (req, res) => {
    const activationItemId = req.params.campaignProductAssignmentId;
    const date = todayDateOnly();
    const { openingStock, soldToday, otherInterestedCustomers, reorderFlag } = req.body as {
      openingStock?: number;
      soldToday?: number;
      otherInterestedCustomers?: number;
      reorderFlag?: boolean;
    };

    const activationItem = await prisma.activationItem.findUnique({ where: { id: activationItemId } });
    if (!activationItem) throw new ApiError(404, "NOT_FOUND", "Stock line not found");

    const existing = await prisma.salesRecord.findUnique({
      where: { activationItemId_date: { activationItemId, date } },
    });

    const nextOpeningStock = openingStock ?? existing?.openingStock ?? 0;
    const nextSoldToday = soldToday ?? existing?.soldToday ?? 0;
    if (nextSoldToday > nextOpeningStock) {
      throw new ApiError(400, "VALIDATION_ERROR", "soldToday cannot exceed openingStock", "soldToday");
    }

    const updated = await prisma.salesRecord.upsert({
      where: { activationItemId_date: { activationItemId, date } },
      create: {
        activationItemId,
        date,
        openingStock: nextOpeningStock,
        soldToday: nextSoldToday,
        otherInterestedCustomers: otherInterestedCustomers ?? 0,
        reorderFlag: reorderFlag ?? false,
      },
      update: {
        ...(openingStock != null ? { openingStock } : {}),
        ...(soldToday != null ? { soldToday } : {}),
        ...(otherInterestedCustomers != null ? { otherInterestedCustomers } : {}),
        ...(reorderFlag != null ? { reorderFlag } : {}),
      },
    });

    return ok(res, { ...updated, remainingStock: updated.openingStock - updated.soldToday });
  })
);

export default router;
