import { NextFunction, Request, Response } from "express";
import { prisma } from "../config/prisma";
import { ApiError } from "../utils/apiResponse";
import { OutletScopeType } from "@prisma/client";

export interface ResolvedCampaignGrant {
  campaignId: string;
  scopeType: OutletScopeType;
  outletIds: string[]; // only meaningful when scopeType === "subset"
}

declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace Express {
    interface Request {
      campaignGrant?: ResolvedCampaignGrant;
    }
  }
}

/**
 * Loads and enforces the caller's CampaignAccessGrant for :campaignId.
 * Super Admin (roleId === "adm") bypasses the grant table entirely — they
 * see every campaign. Everyone else (usr/supervisor/sponsor) must have an
 * explicit grant row.
 *
 * On success, attaches req.campaignGrant so downstream handlers can apply
 * outlet-level filtering via outletIdsAllowed()/assertOutletAllowed().
 */
export async function requireCampaignAccess(req: Request, res: Response, next: NextFunction) {
  const campaignId = req.params.campaignId;
  if (!req.user) {
    throw new ApiError(401, "TOKEN_EXPIRED", "Not authenticated");
  }

  if (req.user.roleId === "adm") {
    req.campaignGrant = { campaignId, scopeType: "all", outletIds: [] };
    return next();
  }

  const grant = await prisma.campaignAccessGrant.findUnique({
    where: { userId_campaignId: { userId: req.user.sub, campaignId } },
  });

  if (!grant) {
    throw new ApiError(403, "FORBIDDEN", "You do not have access to this campaign");
  }

  req.campaignGrant = {
    campaignId,
    scopeType: grant.scopeType,
    outletIds: grant.outletIds,
  };
  next();
}

/** Returns undefined if the grant covers all outlets, else the allow-list. */
export function outletIdsAllowed(req: Request): string[] | undefined {
  if (!req.campaignGrant || req.campaignGrant.scopeType === "all") return undefined;
  return req.campaignGrant.outletIds;
}

/** Throws 403 if a specific outlet falls outside the caller's grant. */
export function assertOutletAllowed(req: Request, outletId: string) {
  const allowed = outletIdsAllowed(req);
  if (allowed && !allowed.includes(outletId)) {
    throw new ApiError(403, "FORBIDDEN", "You do not have access to this outlet");
  }
}
