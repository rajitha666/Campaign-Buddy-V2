import { NextFunction, Request, Response } from "express";
import { ApiError } from "../utils/apiResponse";
import { verifyStaffAccessToken, StaffTokenPayload } from "../utils/jwt";

declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace Express {
    interface Request {
      staff?: StaffTokenPayload;
    }
  }
}

export function staffAuth(req: Request, res: Response, next: NextFunction) {
  const header = req.headers.authorization;
  if (!header?.startsWith("Bearer ")) {
    throw new ApiError(401, "TOKEN_EXPIRED", "Missing or invalid Authorization header");
  }

  const token = header.slice("Bearer ".length);
  try {
    req.staff = verifyStaffAccessToken(token);
    next();
  } catch {
    throw new ApiError(401, "TOKEN_EXPIRED", "Invalid or expired token");
  }
}
