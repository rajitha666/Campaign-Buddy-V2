import { NextFunction, Request, Response } from "express";
import { ApiError, errorResponse } from "../utils/apiResponse";

export function notFoundHandler(req: Request, res: Response) {
  return errorResponse(res, new ApiError(404, "NOT_FOUND", `No route for ${req.method} ${req.path}`));
}

// eslint-disable-next-line @typescript-eslint/no-unused-vars
export function errorHandler(err: unknown, req: Request, res: Response, next: NextFunction) {
  if (err instanceof ApiError) {
    return errorResponse(res, err);
  }

  console.error(err);
  return errorResponse(res, new ApiError(500, "SERVER_ERROR", "Something went wrong"));
}

// Wraps an async route handler so thrown/rejected errors reach errorHandler
export function asyncHandler(
  fn: (req: Request, res: Response, next: NextFunction) => Promise<unknown>
) {
  return (req: Request, res: Response, next: NextFunction) => {
    fn(req, res, next).catch(next);
  };
}
