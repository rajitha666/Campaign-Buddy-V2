import { NextFunction, Request, Response } from "express";
import { ApiError } from "../utils/apiResponse";
import { verifyUserAccessToken, UserTokenPayload } from "../utils/jwt";

declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace Express {
    interface Request {
      user?: UserTokenPayload;
    }
  }
}

export function userAuth(req: Request, res: Response, next: NextFunction) {
  const header = req.headers.authorization;
  if (!header?.startsWith("Bearer ")) {
    throw new ApiError(401, "TOKEN_EXPIRED", "Missing or invalid Authorization header");
  }

  const token = header.slice("Bearer ".length);
  try {
    req.user = verifyUserAccessToken(token);
    next();
  } catch {
    throw new ApiError(401, "TOKEN_EXPIRED", "Invalid or expired token");
  }
}

/**
 * Restricts a route to specific Role ids, e.g. requireRole("adm", "usr").
 * Use after userAuth. Supervisor/Sponsor roles are read-only by convention —
 * write routes should list only "adm" and "usr" here.
 */
export function requireRole(...roleIds: string[]) {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.user || !roleIds.includes(req.user.roleId)) {
      throw new ApiError(403, "FORBIDDEN", "Your role does not permit this action");
    }
    next();
  };
}
