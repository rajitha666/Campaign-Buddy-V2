import { Response } from "express";

export function ok(res: Response, data: unknown, status = 200) {
  return res.status(status).json({ data });
}

export function okList(res: Response, data: unknown[], total: number, status = 200) {
  return res.status(status).json({ data, meta: { total } });
}

export function noContent(res: Response) {
  return res.status(204).send();
}

export class ApiError extends Error {
  status: number;
  code: string;
  field?: string;

  constructor(status: number, code: string, message: string, field?: string) {
    super(message);
    this.status = status;
    this.code = code;
    this.field = field;
  }
}

export function errorResponse(res: Response, err: ApiError) {
  return res.status(err.status).json({
    error: {
      code: err.code,
      message: err.message,
      ...(err.field ? { field: err.field } : {}),
    },
  });
}
