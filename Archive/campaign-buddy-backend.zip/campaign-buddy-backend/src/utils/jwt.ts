import jwt from "jsonwebtoken";
import { env } from "../config/env";

export interface StaffTokenPayload {
  sub: string; // staff id
  type: "staff";
  userType: "promoter" | "supervisor";
}

export interface UserTokenPayload {
  sub: string; // user id
  type: "user";
  roleId: string;
}

export function signStaffAccessToken(payload: Omit<StaffTokenPayload, "type">): string {
  return jwt.sign({ ...payload, type: "staff" }, env.staffJwtSecret, {
    expiresIn: env.staffJwtExpiresIn,
  });
}

export function verifyStaffAccessToken(token: string): StaffTokenPayload {
  return jwt.verify(token, env.staffJwtSecret) as StaffTokenPayload;
}

export function signUserAccessToken(payload: Omit<UserTokenPayload, "type">): string {
  return jwt.sign({ ...payload, type: "user" }, env.userJwtSecret, {
    expiresIn: env.userJwtExpiresIn,
  });
}

export function verifyUserAccessToken(token: string): UserTokenPayload {
  return jwt.verify(token, env.userJwtSecret) as UserTokenPayload;
}
