import dotenv from "dotenv";

dotenv.config();

function required(name: string): string {
  const value = process.env[name];
  if (!value) {
    throw new Error(`Missing required env var: ${name}`);
  }
  return value;
}

export const env = {
  port: Number(process.env.PORT ?? 4000),
  nodeEnv: process.env.NODE_ENV ?? "development",

  staffJwtSecret: required("STAFF_JWT_SECRET"),
  staffJwtExpiresIn: Number(process.env.STAFF_JWT_EXPIRES_IN ?? 3600),
  staffRefreshTokenTtlDays: Number(process.env.STAFF_REFRESH_TOKEN_TTL_DAYS ?? 30),

  userJwtSecret: required("USER_JWT_SECRET"),
  userJwtExpiresIn: process.env.USER_JWT_EXPIRES_IN ?? "8h",

  bcryptSaltRounds: Number(process.env.BCRYPT_SALT_ROUNDS ?? 10),
};
