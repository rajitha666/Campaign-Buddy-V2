import express from "express";
import cors from "cors";
import helmet from "helmet";
import morgan from "morgan";
import mobileRouter from "./modules/mobile";
import adminRouter from "./modules/admin";
import { errorHandler, notFoundHandler } from "./middleware/errorHandler";

export function createApp() {
  const app = express();

  app.use(helmet());
  app.use(cors());
  app.use(express.json());
  app.use(morgan(process.env.NODE_ENV === "development" ? "dev" : "combined"));

  app.get("/health", (req, res) => res.json({ status: "ok" }));

  // Mobile field-rep API — Staff JWT, self-scoped
  app.use("/v1", mobileRouter);

  // Admin / Supervisor / Sponsor web portal API — User JWT, campaign/outlet-scoped
  app.use("/admin/v1", adminRouter);

  app.use(notFoundHandler);
  app.use(errorHandler);

  return app;
}
