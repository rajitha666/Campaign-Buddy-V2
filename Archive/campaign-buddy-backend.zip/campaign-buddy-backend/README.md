# Campaign Buddy Backend

Unified Node.js/TypeScript + Express + PostgreSQL (Prisma) backend serving:

- **Mobile app** (`/v1/*`) — Staff JWT, self-scoped. Field-rep login, attendance, foreground location pings, daily stats, product/stock updates, sales summary, time off, performance.
- **Admin / Supervisor / Sponsor web portal** (`/admin/v1/*`) — one login, one API, permission tiers via `Role` + `CampaignAccessGrant`. Campaign is the tenancy boundary: each campaign has its own item catalog, staff roster (Activations), and access grants.

See `/mnt/project/CampaignBuddy_Unified_Backend_Spec.md` (or the copy in this repo's parent conversation) for the full architecture rationale.

## Setup

```bash
npm install
cp .env.example .env        # then edit DATABASE_URL and JWT secrets
npx prisma migrate dev --name init
npm run prisma:seed
npm run dev
```

Server starts on `http://localhost:4000`. Health check: `GET /health`.

Seeded logins (from `prisma/seed.ts`):
- **Admin portal:** `admin` / `ChangeMe123!` (role: `adm`, sees all campaigns)
- **Mobile app:** `sktest` / `Field123!` (Staff, has an Activation on the seeded "Sktest Activation" campaign)

## Project layout

```
prisma/
  schema.prisma          — full data model (see §2 of the spec doc)
  seed.ts                — Roles, a Super Admin User, and a sample campaign end-to-end
src/
  config/                — env loader, Prisma client singleton
  utils/                 — JWT signing, password hashing, { data }/{ error } response envelope
  middleware/
    staffAuth.ts          — mobile JWT verification
    userAuth.ts           — web portal JWT verification + requireRole()
    campaignAccess.ts      — loads CampaignAccessGrant, enforces outlet-level scoping (the RBAC core)
    errorHandler.ts        — ApiError → { error: { code, message, field } }, asyncHandler wrapper
  modules/
    mobile/               — /v1/* routes (auth, me, attendance, location, stats, products, sales-summary, time-off, performance)
    admin/                — /admin/v1/* routes (auth, catalog, staff, campaigns, activations, operations, reports, rbac)
  app.ts, server.ts
```

## How the RBAC actually works

1. A `User` logs in once at `POST /admin/v1/auth/login` regardless of whether they're an Admin, Supervisor, or Sponsor — the JWT just carries their `roleId`.
2. Every `/admin/v1/campaigns/:campaignId/...` route passes through `requireCampaignAccess`, which looks up a `CampaignAccessGrant` for `(user, campaignId)`. Super Admin (`roleId === "adm"`) bypasses this and sees everything.
3. If the grant's `scopeType` is `"subset"`, every outlet-scoped read/write additionally checks the requested `outletId` against the grant's `outletIds` via `assertOutletAllowed()` / `outletIdsAllowed()`.
4. `requireRole("adm", "usr")` gates writes — Supervisor and Sponsor roles never reach a write handler regardless of what the client sends, because those roles are simply never listed.
5. The **campaign switcher** in the web portal is just `GET /admin/v1/campaigns`, which returns exactly the campaigns the logged-in User has a grant for.

Granting a Supervisor or Sponsor access is one call: `POST /admin/v1/users/:id/campaign-access` with `{ campaignId, scopeType: "all" | "subset", outletIds? }`.

## Decisions on the three open questions (now implemented)

1. **One open shift at a time, globally.** `POST /v1/attendance/check-in` checks for *any* open `AttendanceRecord` (checkInAt set, checkOutAt null) across every `Activation` for that Staff member, not just the one being checked into. If found, it returns `409 ALREADY_CHECKED_IN` — moonlighting across concurrent campaigns is blocked.
2. **Auto-grant on supervisor assignment.** Setting `Activation.supervisorStaffId` (on create or update, in `activations.routes.ts`) auto-creates/expands a `CampaignAccessGrant` for that supervisor's linked `User` account (via `Staff.linkedUserId`), scoped to that outlet. A no-op if the supervisor has no portal login yet. It only ever *adds* access — reassigning a supervisor away from an outlet does not revoke their prior grant; that stays a manual `DELETE /admin/v1/users/:id/campaign-access/:campaignId` (or narrowing the grant's `outletIds` via a fresh `POST`).
3. **Multiple sponsors per campaign — already supported structurally**, since `CampaignAccessGrant` is one row per `(user, campaign)`. Added `GET /admin/v1/campaigns/:campaignId/access` so an admin can see everyone (sponsors, supervisors, admins) with access to a given campaign in one call, rather than querying per-user.

## Known simplifications / things to firm up before production

- Password reset (`/v1/auth/forgot-password`) is a stub — wire up an email/SMS provider.
- `SupervisorTask` has a schema/table but no CRUD endpoints yet (matches the earlier scoping decision to defer this).
- No automated tests yet — recommend adding integration tests per module before deploying, especially around the global check-in lock and the campaign-access auto-grant.
