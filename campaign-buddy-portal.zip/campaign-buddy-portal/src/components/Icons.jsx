// Small inline icon set, reused across sidebar + tables. Kept as raw SVG
// (no icon package dependency) to match the original prototype exactly.
export const ICONS = {
  dashboard: <svg viewBox="0 0 24 24" fill="none"><path d="M4 11l8-7 8 7v9a1 1 0 01-1 1h-4v-6H9v6H5a1 1 0 01-1-1z" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round" /></svg>,
  clients: <svg viewBox="0 0 24 24" fill="none"><rect x="3" y="7" width="18" height="13" rx="2" stroke="currentColor" strokeWidth="1.8" /><path d="M8 7V5a2 2 0 012-2h4a2 2 0 012 2v2" stroke="currentColor" strokeWidth="1.8" /></svg>,
  campaigns: <svg viewBox="0 0 24 24" fill="none"><path d="M3 11l14-7v16L3 13v-2z" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round" /><path d="M7 13v5a2 2 0 002 2h1" stroke="currentColor" strokeWidth="1.8" /></svg>,
  outlets: <svg viewBox="0 0 24 24" fill="none"><path d="M12 21s7-6.5 7-12a7 7 0 10-14 0c0 5.5 7 12 7 12z" stroke="currentColor" strokeWidth="1.8" /><circle cx="12" cy="9" r="2.4" stroke="currentColor" strokeWidth="1.8" /></svg>,
  staff: <svg viewBox="0 0 24 24" fill="none"><circle cx="12" cy="8" r="3.6" stroke="currentColor" strokeWidth="1.8" /><path d="M4 20c1.7-4.3 4.9-6.4 8-6.4s6.3 2.1 8 6.4" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" /></svg>,
  sales: <svg viewBox="0 0 24 24" fill="none"><path d="M3 12l4-2 4 5 6-10 4 3" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" /></svg>,
  supervisors: <svg viewBox="0 0 24 24" fill="none"><path d="M9 11l2 2 4-4" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" /><circle cx="12" cy="12" r="9" stroke="currentColor" strokeWidth="1.8" /></svg>,
  items: <svg viewBox="0 0 24 24" fill="none"><rect x="4" y="7" width="16" height="13" rx="2" stroke="currentColor" strokeWidth="1.8" /><path d="M8 7V5.5A2.5 2.5 0 0110.5 3h3A2.5 2.5 0 0116 5.5V7" stroke="currentColor" strokeWidth="1.8" /></svg>,
  tracking: <svg viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="3" stroke="currentColor" strokeWidth="1.8" /><path d="M12 3v3M12 18v3M3 12h3M18 12h3" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" /></svg>,
  reports: <svg viewBox="0 0 24 24" fill="none"><path d="M5 20V12M12 20V4M19 20V9" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" /></svg>,
  users: <svg viewBox="0 0 24 24" fill="none"><circle cx="9" cy="8" r="3" stroke="currentColor" strokeWidth="1.8" /><path d="M2 20c1.2-3.6 3.6-5.4 7-5.4s5.8 1.8 7 5.4" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" /><path d="M16 4.5a3 3 0 010 6" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" /><path d="M19 14.5c1.8.7 3 2.2 3.7 4.5" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" /></svg>,
  roles: <svg viewBox="0 0 24 24" fill="none"><path d="M12 3l7 3v6c0 5-3 8-7 9-4-1-7-4-7-9V6l7-3z" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round" /></svg>,
  updatesales: <svg viewBox="0 0 24 24" fill="none"><path d="M4 12h16M4 6h10M4 18h13" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" /></svg>,
  view: <svg width="14" height="14" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="3" stroke="currentColor" strokeWidth="1.8" /><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7z" stroke="currentColor" strokeWidth="1.8" /></svg>,
  edit: <svg width="14" height="14" viewBox="0 0 24 24" fill="none"><path d="M4 20l1-4L16.5 4.5a2 2 0 012.8 0l.2.2a2 2 0 010 2.8L8 19l-4 1z" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round" /></svg>,
  delete: <svg width="14" height="14" viewBox="0 0 24 24" fill="none"><path d="M5 7h14M9 7V5a2 2 0 012-2h2a2 2 0 012 2v2m-9 0l1 12a2 2 0 002 2h4a2 2 0 002-2l1-12" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" /></svg>,
  target: <svg width="14" height="14" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="8" stroke="currentColor" strokeWidth="1.8" /><circle cx="12" cy="12" r="3" stroke="currentColor" strokeWidth="1.8" /></svg>,
  close: <svg width="14" height="14" viewBox="0 0 24 24" fill="none"><path d="M6 6l12 12M18 6L6 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" /></svg>,
  search: <svg width="15" height="15" viewBox="0 0 24 24" fill="none"><circle cx="11" cy="11" r="7" stroke="currentColor" strokeWidth="1.8" /><path d="M21 21l-4-4" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" /></svg>,
  chevron: <svg width="13" height="13" viewBox="0 0 24 24" fill="none"><path d="M6 9l6 6 6-6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></svg>,
};
